/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package xlsParser.template;

import java.io.FileNotFoundException;
import java.io.IOException;
import jxl.read.biff.BiffException;

/**
 *
 * @author Salm
 */
public class Test {
    public static void main(String []args) throws FileNotFoundException, IOException, BiffException
    {
//        Gson gson = new GsonBuilder().setPrettyPrinting()
//                .create();
//        
//        XLSWorkbook wb = XLSReader.read("test.xls");
//        XLSWbTemplate templ = new XLSWbTemplate(gson.fromJson(new FileReader("test.json"), LinkedHashMap.class));
//        
//        System.out.println(gson.toJson(templ.parse(wb)));
    }
}
